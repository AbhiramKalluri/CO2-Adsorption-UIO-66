for k-point, smearing, ecutwfc and ecutrho convergence, the same input files were overwritten accordingly by changing input parameters to obtain the results, in turn some of the output files have also been overwritten. 

the actual structures of the molecule are also attached in .xyz format

the files shared by the authors have been saved in the compressed folder. some files are in gaussian input format, which were converted to .xyz format using chatGPT for preparing the input files. 

in the "MISC dump" folder, the other attempts of guessing the site, and other failed attempts are placed (Just in case needed)